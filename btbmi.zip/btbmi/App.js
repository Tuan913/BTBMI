import React, { useState } from "react";
import { StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";

const InputField = ({ label, value, onChangeText, placeholder, keyboardType }) => (
  <View style={styles.inputContainer}>
    <Text style={styles.inputLabel}>{label}</Text>
    <TextInput
      style={styles.input}
      placeholder={placeholder}
      keyboardType={keyboardType}
      value={value}
      onChangeText={onChangeText}
    />
  </View>
);

const BMICalculator = () => {
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [BMI, setBMI] = useState(0);
  const [BMICategory, setBMICategory] = useState("");

  const computeBMI = () => {
    const weightInKg = parseFloat(weight);
    const heightInM = parseFloat(height) / 100;
    const bmi = weightInKg / (heightInM * heightInM);
    setBMI(bmi);

    if (bmi < 18.5) {
      setBMICategory("Underweight");
    } else if (bmi < 25) {
      setBMICategory("Normal Weight");
    } else if (bmi < 30) {
      setBMICategory("Overweight");
    } else {
      setBMICategory("Obese");
    }
  };

  const clearFields = () => {
    setWeight("");
    setHeight("");
    setBMI(0);
    setBMICategory("");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.name}>Nguyễn Hoàng Tuấn</Text>
      <Text style={styles.title}>BMI Calculator</Text>
      <InputField
        label="Weight (KG)"
        placeholder="Enter weight"
        keyboardType="numeric"
        value={weight}
        onChangeText={(text) => setWeight(text)}
      />
      <InputField
        label="Height (CM)"
        placeholder="Enter height"
        keyboardType="numeric"
        value={height}
        onChangeText={(text) => setHeight(text)}
      />
      <TouchableOpacity style={styles.button} onPress={computeBMI}>
        <Text style={styles.buttonText}>Compute BMI</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.clearButton} onPress={clearFields}>
        <Text style={styles.buttonText}>Clear</Text>
      </TouchableOpacity>
      <Text style={styles.result}>BMI: {BMI.toFixed(2)}</Text>
      {BMICategory !== "" && (
        <Text style={styles.result}>Category: {BMICategory}</Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#72ff56",
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "red",
    ma:20,
  },
  name: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#000000",
    marginBottom:20,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
    marginTop: 20,
  },
  inputLabel: {
    marginRight: 10,
    fontSize: 16,
    fontWeight: "bold",
    color: "black",
  },
  input: {
    flex: 1,
    height: 40,
    borderColor: "black",
    borderWidth: 1,
    padding: 10,
    backgroundColor: '#bf0000',
    color:'white',
  },
  button: {
    width: "40%",
    height: 40,
    backgroundColor: "brown",
    color: "#AF2655",
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
    margin: 15,
  },
  clearButton: {
    width: "40%",
    height: 40,
    backgroundColor: "grey",
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
    margin: 10,
  },
  buttonText: {
    fontSize: 17,
    fontWeight: "bold",
    color: "black",
  },
  result: {
    fontSize: 18,
    fontWeight: "bold",
    margin: 10,
    color: "red",
  },
});

export default BMICalculator;